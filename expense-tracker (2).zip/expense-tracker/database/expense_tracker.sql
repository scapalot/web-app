-- =============================================
-- Student Expense Tracker Database
-- Fully Working & Updated: November 2025
-- Works perfectly with XAMPP + phpMyAdmin
-- =============================================

DROP DATABASE IF EXISTS expense_tracker;
CREATE DATABASE expense_tracker CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE expense_tracker;

-- Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Expenses Table
CREATE TABLE expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL CHECK (amount >= 0),
    category VARCHAR(50) NOT NULL,
    description TEXT,
    expense_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_date (expense_date),
    INDEX idx_category (category),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Insert a Default Test User (for instant login)
-- Email: student@example.com
-- Password: 123456
INSERT INTO users (name, email, password) VALUES 
('Demo Student', 'student@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample Expenses for the Demo User (user_id = 1)
INSERT INTO expenses (user_id, amount, category, description, expense_date) VALUES
(1, 350.00, 'Food', 'Groceries from Big Bazaar', '2025-11-15'),
(1, 120.00, 'Transport', 'Uber to college', '2025-11-16'),
(1, 850.00, 'Education', 'Stationery & Xerox', '2025-11-18'),
(1, 200.00, 'Entertainment', 'Movie with friends', '2025-11-20'),
(1, 450.00, 'Food', 'Pizza party', '2025-11-22'),
(1, 80.00, 'Transport', 'Bus pass recharge', '2025-11-25'),
(1, 600.00, 'Shopping', 'New hoodie', '2025-11-26'),
(1, 150.00, 'Health', 'Medicines', '2025-11-27');

-- Optional: Add more categories if you want dropdown suggestions
-- (You can expand this later via PHP if needed)

-- =============================================
-- ALL SET! Now import this file in phpMyAdmin
-- Login Credentials for testing:
-- Email: student@example.com
-- Password: 123456
-- =============================================