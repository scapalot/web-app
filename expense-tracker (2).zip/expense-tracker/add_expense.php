<?php
session_start();
if (!isset($_SESSION['user_id'])) header("Location: index.php");
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO expenses (user_id, amount, category, description, expense_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("idsss", $user_id, $amount, $category, $description, $date);
    $stmt->execute();
    header("Location: dashboard.php?added=1");
}
?>

<!DOCTYPE html>
<html><head><title>Add Expense</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head><body>
<?php include 'includes/header.php'; ?>

<div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card shadow">
        <div class="card-header bg-primary text-white">
          <h4><i class="fas fa-plus-circle"></i> Add New Expense</h4>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="mb-3">
              <label class="form-label"><i class="fas fa-money-bill-wave text-success"></i> Amount (KSh)</label>
              <input type="number" step="0.01" name="amount" class="form-control form-control-lg" placeholder="e.g. 1250.50" required>
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-tags"></i> Category</label>
              <select name="category" class="form-select form-select-lg" required>
                <option value="">-- Choose Category --</option>
                <option>Food</option>
                <option>Transport</option>
                <option>Education</option>
                <option>Entertainment</option>
                <option>Shopping</option>
                <option>Health</option>
                <option>Other</option>
              </select>
            </div>

            <div class="mb-3">
              <label class="form-label"><i class="fas fa-comment"></i> Description (Optional)</label>
              <input type="text" name="description" class="form-control" placeholder="e.g. Lunch at Java House">
            </div>

            <div class="mb-4">
              <label class="form-label"><i class="fas fa-calendar"></i> Date</label>
              <input type="date" name="date" class="form-control form-control-lg" required>
            </div>

            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
              <a href="dashboard.php" class="btn btn-secondary btn-lg">Cancel</a>
              <button type="submit" class="btn btn-success btn-lg">Save Expense</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
</body></html>