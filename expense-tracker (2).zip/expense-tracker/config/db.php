<?php
$host = 'localhost';
$db   = 'expense_tracker';
$user = 'root';
$pass = ''; // Default XAMPP has no password

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>