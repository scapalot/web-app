<footer class="bg-dark text-white py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-money-bill-wave text-success"></i>Expense Tracker</h5>
                <p class="small opacity-75">
                    Track your Kenyan Shilling expenses wisely. Made for students in Kenya.
                </p>
            </div>
            <div class="col-md-6 text-md-end">
                <p class="mb-1">© <?php echo date('Y'); ?> All Rights Reserved</p>
                <p class="small opacity-75">
                    Made with <i class="fas fa-heart text-danger"></i> in Kenya
                </p>
            </div>
        </div>
        <hr class="bg-light opacity-25">
        <div class="text-center small">
            Powered by PHP • MySQL • Chart.js • Bootstrap 5
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="assets/js/script.js"></script>
</body>
</html>