<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

include 'config/db.php';
$user_id = $_SESSION['user_id'];
$id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("SELECT * FROM expenses WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$expense = $result->fetch_assoc();

if (!$expense) {
    echo "<script>alert('Expense not found!'); window.location='dashboard.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $date = $_POST['date'];

    $update = $conn->prepare("UPDATE expenses SET amount = ?, category = ?, description = ?, expense_date = ? WHERE id = ? AND user_id = ?");
    $update->bind_param("dsssii", $amount, $category, $description, $date, $id, $user_id);
    $update->execute();

    echo "<script>alert('Expense updated successfully!'); window.location='dashboard.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Expense</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card shadow">
                    <div class="card-header bg-warning text-dark">
                        <h4><i class="fas fa-edit"></i> Edit Expense</h4>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-money-bill-wave text-success"></i> Amount (KSh)</label>
                                <input type="number" step="0.01" name="amount" class="form-control form-control-lg" 
                                       value="<?php echo htmlspecialchars($expense['amount']); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-tags"></i> Category</label>
                                <select name="category" class="form-select form-select-lg" required>
                                    <option value="">-- Select Category --</option>
                                    <?php
                                    $categories = ['Food', 'Transport', 'Education', 'Entertainment', 'Shopping', 'Health', 'Other'];
                                    foreach ($categories as $cat) {
                                        $selected = ($cat === $expense['category']) ? 'selected' : '';
                                        echo "<option value='$cat' $selected>$cat</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><i class="fas fa-comment"></i> Description</label>
                                <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($expense['description']); ?></textarea>
                            </div>

                            <div class="mb-4">
                                <label class="form-label"><i class="fas fa-calendar"></i> Date</label>
                                <input type="date" name="date" class="form-control form-control-lg" 
                                       value="<?php echo $expense['expense_date']; ?>" required>
                            </div>

                            <div class="d-grid d-md-flex justify-content-md-end gap-2">
                                <a href="dashboard.php" class="btn btn-secondary btn-lg">Cancel</a>
                                <button type="submit" class="btn btn-success btn-lg">Update Expense</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</body>
</html>