<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - Student Expense Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-light">
  <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-4">
        <div class="card shadow">
          <div class="card-header bg-primary text-white text-center">
            <h4>Student Expense Tracker</h4>
          </div>
          <div class="card-body">
            <form action="index.php" method="POST" id="loginForm">
              <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
              </div>
              <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary w-100">Login</button>
            </form>
            <p class="text-center mt-3">Don't have an account? <a href="register.php">Register</a></p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php
  session_start();
  if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      include 'config/db.php';
      $email = $_POST['email'];
      $password = $_POST['password'];

      $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $stmt->store_result();

      if ($stmt->num_rows == 1) {
          $stmt->bind_result($id, $name, $hashed_password);
          $stmt->fetch();
          if (password_verify($password, $hashed_password)) {
              $_SESSION['user_id'] = $id;
              $_SESSION['user_name'] = $name;
              header("Location: dashboard.php");
              exit();
          } else {
              echo "<div class='alert alert-danger text-center'>Invalid password</div>";
          }
      } else {
          echo "<div class='alert alert-danger text-center'>User not found</div>";
      }
      $stmt->close();
  }
  ?>
</body>
</html>