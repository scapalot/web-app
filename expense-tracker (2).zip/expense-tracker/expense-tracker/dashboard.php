<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
include 'config/db.php';
$user_id = $_SESSION['user_id'];

// Total Expenses
$total = $conn->query("SELECT SUM(amount) as total FROM expenses WHERE user_id = $user_id")->fetch_assoc()['total'] ?? 0;

// Category Summary
$categories = $conn->query("SELECT category, SUM(amount) as total FROM expenses WHERE user_id = $user_id GROUP BY category");
$chartData = [];
while ($row = $categories->fetch_assoc()) {
    $chartData['labels'][] = $row['category'];
    $chartData['data'][] = $row['total'];
}

// Recent Expenses
$expenses = $conn->query("SELECT * FROM expenses WHERE user_id = $user_id ORDER BY expense_date DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <?php include 'includes/header.php'; ?>

  <div class="container mt-4">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="card text-white bg-danger mb-3">
          <div class="card-body">
            <h5>Total Expenses</h5>
            <h3>₹<?php echo number_format($total, 2); ?></h3>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <canvas id="expenseChart"></canvas>
      </div>
      <div class="col-md-6">
        <h4>Recent Expenses</h4>
        <a href="add_expense.php" class="btn btn-primary mb-3">+ Add Expense</a>
        <table class="table table-striped">
          <thead><tr><th>Date</th><th>Category</th><th>Amount</th><th>Actions</th></tr></thead>
          <tbody>
            <?php while($exp = $expenses->fetch_assoc()): ?>
            <tr>
              <td><?php echo $exp['expense_date']; ?></td>
              <td><?php echo $exp['category']; ?></td>
              <td>₹<?php echo $exp['amount']; ?></td>
              <td>
                <a href="edit_expense.php?id=<?php echo $exp['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <button onclick="deleteExpense(<?php echo $exp['id']; ?>)" class="btn btn-sm btn-danger">Delete</button>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    const ctx = document.getElementById('expenseChart').getContext('2d');
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: <?php echo json_encode($chartData['labels'] ?? []); ?>,
        datasets: [{
          data: <?php echo json_encode($chartData['data'] ?? []); ?>,
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF']
        }]
      }
    });

    function deleteExpense(id) {
      if (confirm("Delete this expense?")) {
        fetch('delete_expense.php?id=' + id)
          .then(() => location.reload());
      }
    }
  </script>
</body>
</html>