<!-- includes/footer.php -->
<footer class="bg-dark text-white py-5 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-receipt"></i> Student Expense Tracker</h5>
                <p class="small opacity-75">
                    Manage your daily expenses smartly. Track,