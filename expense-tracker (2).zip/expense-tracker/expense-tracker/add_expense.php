<?php
session_start();
if (!isset($_SESSION['user_id'])) header("Location: index.php");
include 'config/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $amount = $_POST['amount'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO expenses (user_id, amount, category, description, expense_date) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("idsss", $user_id, $amount, $category, $description, $date);
    $stmt->execute();
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html><head><title>Add Expense</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head><body>
<div class="container mt-5">
  <h2>Add New Expense</h2>
  <form method="POST">
    <div class="row">
      <div class="col-md-6">
        <input type="number" step="0.01" name="amount" class="form-control mb-3" placeholder="Amount" required>
        <select name="category" class="form-control mb-3" required>
          <option value="">Select Category</option>
          <option>Food</option>
          <option>Transport</option>
          <option>Education</option>
          <option>Entertainment</option>
          <option>Shopping</option>
          <option>Other</option>
        </select>
        <input type="text" name="description" class="form-control mb-3" placeholder="Description">
        <input type="date" name="date" class="form-control mb-3" required>
        <button type="submit" class="btn btn-success">Save Expense</button>
        <a href="dashboard.php" class="btn btn-secondary">Back</a>
      </div>
    </div>
  </form>
</div>
</body></html>