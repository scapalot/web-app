// assets/js/script.js

document.addEventListener('DOMContentLoaded', function () {
    // SweetAlert2 CDN (for beautiful alerts)
    const swalScript = document.createElement('script');
    swalScript.src = 'https://cdn.jsdelivr.net/npm/sweetalert2@11';
    document.head.appendChild(swalScript);

    // Form Validation for Add & Edit Expense
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function (e) {
            const amount = form.querySelector('input[name="amount"]');
            const category = form.querySelector('select[name="category"]');
            const date = form.querySelector('input[name="date"]');

            if (amount && parseFloat(amount.value) <= 0) {
                e.preventDefault();
                Swal.fire('Invalid Amount', 'Please enter a positive amount.', 'error');
                amount.focus();
                return;
            }

            if (category && category.value === '') {
                e.preventDefault();
                Swal.fire('Select Category', 'Please choose an expense category.', 'warning');
                return;
            }

            if (date && !date.value) {
                e.preventDefault();
                Swal.fire('Date Required', 'Please select the expense date.', 'warning');
                return;
            }
        });
    });
});

// Enhanced Delete with SweetAlert2 Confirmation
function deleteExpense(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This expense will be deleted permanently!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch(`delete_expense.php?id=${id}`)
                .then(response => {
                    if (response.ok) {
                        Swal.fire('Deleted!', 'Expense has been removed.', 'success')
                            .then(() => location.reload());
                    } else {
                        Swal.fire('Error', 'Something went wrong.', 'error');
                    }
                });
        }
    });
}

// Optional: Auto-format amount with comma
document.querySelectorAll('input[name="amount"]').forEach(input => {
    input.addEventListener('blur', function () {
        let val = this.value.replace(/,/g, '');
        if (!isNaN(val) && val !== '') {
            this.value = parseFloat(val).toLocaleString('en-IN', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    });
});