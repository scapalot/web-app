<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
include 'config/db.php';
$user_id = $_SESSION['user_id'];

// Total Expenses
$total = $conn->query("SELECT SUM(amount) as total FROM expenses WHERE user_id = $user_id")->fetch_assoc()['total'] ?? 0;

// Category Summary for Chart
$categories = $conn->query("SELECT category, SUM(amount) as total FROM expenses WHERE user_id = $user_id GROUP BY category");
$chartData = [];
while ($row = $categories->fetch_assoc()) {
    $chartData['labels'][] = $row['category'];
    $chartData['data'][] = $row['total'];
}

// Recent Expenses
$expenses = $conn->query("SELECT * FROM expenses WHERE user_id = $user_id ORDER BY expense_date DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - Expense Tracker</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <?php include 'includes/header.php'; ?>

  <div class="container mt-4">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
    <div class="row">
      <div class="col-md-4">
        <div class="card text-white bg-success mb-3">
          <div class="card-body">
            <h5>Total Expenses</h5>
            <h3>KSh <?php echo number_format($total, 2); ?></h3>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-6">
        <canvas id="expenseChart"></canvas>
      </div>
      <div class="col-md-6">
        <h4>Recent Expenses</h4>
        <a href="add_expense.php" class="btn btn-primary mb-3"><i class="fas fa-plus-circle"></i> Add Expense</a>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>Date</th>
              <th>Category</th>
              <th>Amount</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php while($exp = $expenses->fetch_assoc()): ?>
            <tr>
              <td><?php echo date('d M Y', strtotime($exp['expense_date'])); ?></td>
              <td><?php echo htmlspecialchars($exp['category']); ?></td>
              <td><strong>KSh <?php echo number_format($exp['amount'], 2); ?></strong></td>
              <td>
                <a href="edit_expense.php?id=<?php echo $exp['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                <button onclick="deleteExpense(<?php echo $exp['id']; ?>)" class="btn btn-sm btn-danger">Delete</button>
              </td>
            </tr>
            <?php endwhile; ?>
            <?php if ($expenses->num_rows == 0): ?>
            <tr><td colspan="4" class="text-center py-4">No expenses yet. <a href="add_expense.php">Add your first one!</a></td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <?php include 'includes/footer.php'; ?>

  <script>
    const ctx = document.getElementById('expenseChart').getContext('2d');
    new Chart(ctx, {
      type: 'pie',
      data: {
        labels: <?php echo json_encode($chartData['labels'] ?? []); ?>,
        datasets: [{
          data: <?php echo json_encode($chartData['data'] ?? []); ?>,
          backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#C9CBCF']
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom' },
          title: { display: true, text: 'Expenses by Category (KSh)' }
        }
      }
    });

    function deleteExpense(id) {
      Swal.fire({
        title: 'Delete Expense?',
        text: "This action cannot be undone!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          fetch(`delete_expense.php?id=${id}`)
            .then(() => {
              Swal.fire('Deleted!', 'Expense removed.', 'success').then(() => location.reload());
            });
        }
      });
    }
  </script>
</body>
</html>